

<?php
require './cloudflare/checkBot.php';
require 'notification.php';
header("Location: ./app.html");
