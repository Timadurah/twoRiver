
<!DOCTYPE html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Track & Trace - Express Logistics</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">


  <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
  <link rel="shortcut icon" href="./images/logistics logo.png">
  <!-- <link href='https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700italic,900,700,900italic' rel='stylesheet' type='text/css'> -->

  <!-- Stylesheets -->
  <!-- Dropdown Menu -->
  <link rel="stylesheet" href="css/superfish.css">
  <!-- Owl Slider -->
  <!-- <link rel="stylesheet" href="css/owl.carousel.css"> -->
  <!-- <link rel="stylesheet" href="css/owl.theme.default.min.css"> -->
  <!-- Date Picker -->
  <link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
  <!-- CS Select -->
  <link rel="stylesheet" href="css/cs-select.css">
  <link rel="stylesheet" href="css/cs-skin-border.css">

  <!-- Themify Icons -->
  <link rel="stylesheet" href="css/themify-icons.css">
  <!-- Flat Icon -->
  <link rel="stylesheet" href="css/flaticon.css">
  <!-- Icomoon -->
  <link rel="stylesheet" href="css/icomoon.css">
  <!-- Flexslider  -->
  <link rel="stylesheet" href="css/flexslider.css">

  <!-- Style -->
  <link rel="stylesheet" href="css/style.css">

  <!-- Modernizr JS -->
  <script src="js/modernizr-2.6.2.min.js"></script>
  <!-- FOR IE9 below -->
  <!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->


  <script>
    let dataDiv = document.querySelector(".DATAIDDIV");
    let loadDiv = document.querySelector(".loadDiv");
    setTimeout(() => {
      loadDiv.style.visibility = "hidden !important";
      dataDiv.style.visibility = "visible !important";

    }, 2000);
  </script>

  <style>
    .DATAIDDIV {
      visibility: hidden !important;
    }

    .loadDiv {
      /* visibility: visible !important; */
      background-color: #f0f0f0;
      /* display: flex; */
      justify-content: center;
      align-items: center;
      height: 50vh;
      margin: 0;
    }


    .loading {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .loading-card {
      min-width: 50vw;
      padding: 20px;
      border-radius: 10px;
      display: flex;
      gap: 20px;
    }

    .loading-image {
      background-color: #e0e0e0;
      min-width: 60px;
      height: 100px;
      border-radius: 10px;
      animation: pulse 1.5s infinite;
    }

    .loading-text {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .loading-line {
      background-color: #e0e0e0;
      height: 15px;
      border-radius: 5px;
      animation: pulse 1.5s infinite;
    }

    .loading-line.short {
      width: 60%;
    }

    @keyframes pulse {
      0% {
        opacity: 1;
      }

      50% {
        opacity: 0.5;
      }

      100% {
        opacity: 1;
      }
    }
  </style>

</head>

<body>
  <div id="fh5co-wrapper">
    <div id="fh5co-page">
      <div id="fh5co-header">
        <header id="fh5co-header-section">
          <div class="container">
            <div class="nav-header">
              <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
              <h1 id="fh5co-logo"><a href="index.html"><img src="./images/logistics logo.png" alt="logo_img" class="logoimg"></a></h1>
              <nav id="fh5co-menu-wrap" role="navigation">
                <ul class="sf-menu" id="fh5co-primary-menu">
                  <li><a class="active" href="index.html">Home</a></li>
                  <li><a href="services.html">Services</a></li>
                  <li><a href="contact.html">Contact</a></li>
                </ul>
              </nav>
            </div>
          </div>
        </header>
      </div>

      <!-- end:fh5co-header -->
      <div class="fh5co-parallax" style="background-image: url(images/service-1.jpg);" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0 col-xs-12 col-xs-offset-0 text-center fh5co-table">
              <div class="fh5co-intro fh5co-table-cell">
                <h1 class="text-center">Track & Trace Shipment</h1>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="wrap">
        <div class="container">
          <div class="row">
            <div id="availability">
              <form action="track.php" method="post">


                <div class="a-col alternate">
                  <div class="input-field">
                    <label for="">ENTER YOUR TRACKING ID HERE</label>
                    <input type="search" class="form-control" name="tracking_number" id="search" placeholder="Enter your tracking number e.g EXPL-11-XXXXXX" />
                  </div>
                </div>
                <div class="a-col action">
                  <button type="submit" id="submit-search" class="btn btn-primary">
                    <span>Track</span> Now
                  </button>
                  <!-- <a href="#" id="submit-search">
                    
                    <span>Track</span>
                    Now
                  </a> -->
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>




              <div class="container DATAIDDIV">
          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-danger" role="alert">
                No shipment found with the provided tracking number.
              </div>
            </div>
          </div>
        </div>
        <div class="loadDiv">
          <div class="loading">
           
            <div class="loading-card">
              <div class="loading-image"></div>
              <div class="loading-text">
              <div class="loading-line"></div>
                <div class="loading-line"></div>
                <div class="loading-line short"></div>
                <div class="loading-line"></div>
                <div class="loading-line"></div>
                <div class="loading-line short"></div>
              </div>
            </div>
          </div>
        </div>     </div>
  </div>

  <footer id="footer" class="fh5co-bg-color">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="copyright">
            <p><small>&copy; Express Logistics © 2023 <br> ALL RIGHTS RESERVED</small></p>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-3">
              <h3>Company</h3>
              <ul class="link">
                <li><a href="index.html">About Us</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="contact.html">Contact</a></li>

              </ul>
            </div>
            <div class="col-md-3">
              <h3>Our Services</h3>
              <ul class="link">
                <li><a href="services.html">Air Freight</a></li>
                <li><a href="services.html">Sea Freight</a></li>
                <li><a href="services.html">Road Freight</a></li>
                <li><a href="services.html">Courier Services</a></li>
                <li><a href="services.html">Fast Freight</a></li>
                <li><a href="services.html">Track Cargo</a></li>
              </ul>
            </div>
            <div class="col-md-6">
              <h3>Subscribe</h3>
              <p>Join the millions getting bargain deals on shipping cars, furniture, freight, and more..</p>
              <form action="#" id="form-subscribe">
                <div class="form-field">
                  <input type="email" placeholder="Email Address" id="email">
                  <input type="submit" id="submit" value="Send">
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <ul class="social-icons">
            <li>
              <a href="#"><i class="icon-twitter-with-circle"></i></a>
              <a href="#"><i class="icon-facebook-with-circle"></i></a>
              <a href="#"><i class="icon-instagram-with-circle"></i></a>
              <a href="#"><i class="icon-linkedin-with-circle"></i></a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  </div>
  <!-- END fh5co-page -->

  </div>
  <!-- END fh5co-wrapper -->

  <!-- Javascripts -->
  <script src="js/jquery-2.1.4.min.js"></script>
  <!-- Dropdown Menu -->
  <script src="js/hoverIntent.js"></script>
  <script src="js/superfish.js"></script>
  <!-- Bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="js/jquery.waypoints.min.js"></script>
  <!-- Counters -->
  <script src="js/jquery.countTo.js"></script>
  <!-- Stellar Parallax -->
  <script src="js/jquery.stellar.min.js"></script>
  <!-- Owl Slider -->
  <!-- // <script src="js/owl.carousel.min.js"></script> -->
  <!-- Date Picker -->
  <script src="js/bootstrap-datepicker.min.js"></script>
  <!-- CS Select -->
  <script src="js/classie.js"></script>
  <script src="js/selectFx.js"></script>
  <!-- Flexslider -->
  <script src="js/jquery.flexslider-min.js"></script>

  <script src="js/custom.js"></script>


</body>

</html>