
        padding: 20px;
        max-width: 80%;
        margin: auto;
        margin-block: 40px;
        border: none;
        gap: 250px;
    
        padding: 2;
        max-width: 80%;
        margin: auto;
        margin-block: 40px;
        border: none;
        gap: 250px;
    
        pa
        padding: 40px;
        max-width: 80%;
        margin: auto;
        margin-block: 40px;
        border: none;
        gap: 250px;
        padding: 20px;
        max-width: 80%;
        margin: auto;
        margin-block: 40px;
        border: none;
        gap: 250px;
    
        padding: 2;
        max-width: 80%;
        margin: auto;
        margin-block: 40px;
        border: none;
        gap: 250px;
    